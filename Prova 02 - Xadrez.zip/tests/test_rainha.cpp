#include "doctest.h"
#include "rainha.h"


TEST_CASE("Testando o Construtor") {
    Rainha rainha(1, 2);
}