#include <iostream>

int main() {
    std::cout << "Implemente um main caso queira" << std::endl;
}
